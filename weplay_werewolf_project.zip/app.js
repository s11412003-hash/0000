
const roles=['狼人','預言家','女巫','平民','平民','獵人','守衛','白痴','戀人','調停者'];
function log(t){document.getElementById('log').innerHTML += '<div>'+t+'</div>'}
function startGame(){
 let cards=document.getElementById('cards');
 cards.innerHTML='';
 roles.forEach((r,i)=>{
   cards.innerHTML += `<div class="card"><h3>${i+1}號玩家</h3><p>${r}</p><p>🟢 存活</p></div>`;
 });
 log('遊戲開始');
 document.getElementById('status').innerText='第1天';
}
function setPhase(p){
 document.getElementById('status').innerText=p;
 log('切換至'+p);
}
